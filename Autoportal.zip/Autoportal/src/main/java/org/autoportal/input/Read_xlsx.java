package org.autoportal.input;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Read_xlsx {
	Properties property;
	
	public Row input_file() throws IOException {
		FileInputStream fs=new FileInputStream(".\\config.properties");
		property = new Properties();
		property.load(fs);
		FileInputStream stream = new FileInputStream(property.getProperty("Xlsx_File_location"));
		Workbook wrk = new XSSFWorkbook(stream);
		Sheet sheet=wrk.getSheetAt(0);
		Row row=sheet.getRow(1);
		return row;
		
	}
	
	
	public String input_name(Row row) throws IOException
	{
		String name=row.getCell(0).getStringCellValue();
		return name;
		
	}
	
	public double input_mobile_no(Row row) throws IOException
	{
		double mobile_no=row.getCell(1).getNumericCellValue();
		return mobile_no;
		
	}
	
	public String input_city(Row row) throws IOException
	{
		String city=row.getCell(2).getStringCellValue();
		return city;
	}
	

}
