package org.autoportal.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Page_factory {
	WebDriver driver;
	@FindBy(xpath="//*[@id=\"brand_find_form_submit\"]")
	WebElement Find_New_Bikes; 
	
	@FindBy(xpath="//*[@id=\"content\"]/div[2]/div/h1/text()")
	WebElement Bike_Finder;
	
	@FindBy(xpath="//*[@id=\"mCSB_1_container\"]/ul/li[1]/label")
	WebElement Brand; 
	
	@FindBy(xpath="//*[@id=\"filter-form\"]/div/div[2]/div[2]/ul/li[6]/label")
	WebElement Body_type; 
	
	@FindBy(xpath="//*[@id=\"filter-form\"]/div/div[3]/div[2]/ul/li[2]/label")
	WebElement Price;
	
	@FindBy(xpath="//*[@id=\"filter-form\"]/div/div[4]/div[2]/ul/li[2]/label")
	WebElement Displacement;
	
	@FindBy(xpath="//*[@id=\"filter-form\"]/div/div[5]/div[2]/ul/li[3]/label")
	WebElement Mileage;
	
	@FindBy(xpath="//*[@id=\"filter-form\"]/div/div[6]/div[2]/ul/li[3]/label")
	WebElement Engine_Type;
	
	@FindBy(xpath="//*[@id=\"filter-form\"]/div/div[7]/div[2]/ul/li[3]/label")
	WebElement Important_Features;
	
	@FindBy(xpath="//*[@id=\"content\"]/div[3]/div/div[2]/div[4]/div[1]/div[1]/div/div[2]/div/div[2]/a")
	WebElement Onroad_Price;
	
	@FindBy(xpath="//*[@id=\"lead_form_name\"]")
	WebElement Name;
	
	@FindBy(xpath="//*[@id=\"lead_form_phone\"]")
	WebElement Mobile_Number;
	
	@FindBy(xpath="//*[@id=\"modal-gop-form-popup\"]/div[2]/div/div[2]/div/form/div[4]/input[2]")
	WebElement City;
	
	@FindBy(xpath="//li[contains(text(),'Coimbatore, Tamil Nadu')]")
	WebElement Citylist;
	
	@FindBy(xpath="//*[@id='lead_form_purchasePeriod']")
	WebElement Buying_time;
	
	@FindBy(xpath="//*[@id=\"lead_form_submit\"]")
	WebElement Proceed;
	
	@FindBy(xpath="//*[@class='form-smsverify']/div[2]/span[4]")
	WebElement Skip;
	
	
	public void driver_init(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);

    }
	

}
