package org.autoportal.utilities;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;



public class Scooter_details extends Page_factory {
	
	static WebDriver driver;

	public Scooter_details(WebDriver driver) {
		this.driver=driver;
		driver_init(driver);
		
	}
	
	
	public void find_new_bikes() {
		
		Find_New_Bikes.click();
	}
	
	public void select_filters() {
		
		
		Brand.click();
		
		 Body_type.click(); Price.click(); Displacement.click(); Mileage.click();
		 Engine_Type.click(); Important_Features.click();
		
}
public void onroad_price() {
				
		Onroad_Price.click();
		//driver.switchTo().alert();
		
		}

	public void enter_name(String name) {
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		Name.sendKeys(name);
		WebDriverWait wait = new WebDriverWait(driver,30);
	}
	
	public void enter_mobile(double mobile_no) {
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		Mobile_Number.sendKeys(String.valueOf(mobile_no));
		WebDriverWait wait = new WebDriverWait(driver,30);
	}
	
	public void enter_city(String city) {
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		City.sendKeys(city);
		WebDriverWait wait = new WebDriverWait(driver,30);
		//WebElement City = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ui-id-13")));
		Citylist.click();
	}
	
	public void select_buytime() {
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		Select s=new Select(Buying_time);
		s.selectByVisibleText("1 week");
		WebDriverWait wait = new WebDriverWait(driver,30);
	}
	
	public void click_proceed_empty() {
		Proceed.click();
	}
	
	public void click_proceed() {
		Proceed.click();
		//driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		WebDriverWait wait = new WebDriverWait(driver,30);
		Skip.click();
		WebDriverWait wait1 = new WebDriverWait(driver,30);
		
	}
	
	/*
	 * public boolean newbikes_isSelected() {
	 * 
	 * return Bike_Finder.isDisplayed();
	 * 
	 * }
	 */
	

}
