package org.autoportal.test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.autoportal.input.Driver_setup;
import org.autoportal.input.Read_xlsx;
import org.autoportal.utilities.Scooter_details;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.autoportal.output.Screenshots;


public class DriverTest 
{
    static WebDriver driver;
    
    ExtentHtmlReporter htmlReporter;
    
    ExtentReports extent;
    //helps to generate the logs in test report.
    ExtentTest test;
    Logger log = LogManager.getLogger("DriverTest.class");
    
    @BeforeClass
    @Parameters({"Browser" ,"url"})
	public void driver_ready(String Browser,String url) throws IOException {
		htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") +"/test-output/Extent_Report.html");
        
        //initialize ExtentReports and attach the HtmlReporter
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
         
        //To add system or environment info by using the setSystemInfo method.
        extent.setSystemInfo("OS", "Windows");
        extent.setSystemInfo("Browser", Browser);
        
        //configuration items to change the look and feel
        //add content, manage tests etc
        htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
        htmlReporter.config().setDocumentTitle("Autoportal");
        htmlReporter.config().setReportName("Automation Execution Report");
        htmlReporter.config().setTheme(com.aventstack.extentreports.reporter.configuration.Theme.DARK);
        
        if(Browser.equalsIgnoreCase("Chrome")) {
			
			Driver_setup obj = new Driver_setup();
			
			driver=obj.getChromeDriver();
			log.info("*******Launching Chrome**********");
			
			
		}
		
		
		else if(Browser.equalsIgnoreCase("Firefox")) {
			
			
			Driver_setup obj = new Driver_setup();
			
			driver=obj.getFirefoxDriver();
			log.info("*********Launching Firefox*********");
		}
		
		
		driver.manage().window().maximize();
		driver.get(url);
		
		driver.manage().timeouts().implicitlyWait(20000, TimeUnit.MILLISECONDS);
		
		//Loan_detailes obj2 = new Loan_detailes();
		//obj2.setup_driver(driver);
		
	}
    
    
    @Test(priority=1,groups="Check Title")
	public void autoportal_TitleTest() {
		String title=driver.getTitle();
		test = extent.createTest("autoportal_test","passed");
		//System.out.println(title);
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		Assert.assertEquals(title, "New Bikes in India 2020. Bike Prices, Images & Reviews | Autoportal | Sports, companies, sport");
		log.info("*******Checking Page Tittle************");
	}
    
    @Test(priority=2,dependsOnMethods="autoportal_TitleTest")
	public void select_newbikes() {
		
    	test = extent.createTest("select_newbikes","passed");	
    	Scooter_details obj2 = new Scooter_details(driver);
		obj2.find_new_bikes();
		//Assert.assertTrue(obj2.newbikes_isSelected());
		log.info("Click on Find New bikes through "+"driver");
	}

    @Test(priority=3,dependsOnMethods="select_newbikes")
	public void select_filters() {
		
    	test = extent.createTest("select_filters","passed");	
    	Scooter_details obj2 = new Scooter_details(driver);
		obj2.select_filters();
		log.info("Click on filters through "+"driver");
	}
    
    @Test(priority=4,dependsOnMethods="select_filters")
    public void on_roadprice() {
    	
    	test=extent.createTest("on_roadprice", "passed");
    	Scooter_details obj2 = new Scooter_details(driver);
    	obj2.onroad_price();
    	log.info("Click on onroad price through"+"driver");
    }
    
    @Test(priority=5,dependsOnMethods = "on_roadprice")
    public void proceed_empty() {
    	
    	test=extent.createTest("proceed_empty", "failed");
    	Scooter_details obj2 = new Scooter_details(driver);
    	obj2.click_proceed_empty();
    	log.info("Test Case failed since fields are empty");
    }
    
    @Test(priority=6,dependsOnMethods="proceed_empty",groups="Outputs")
	public void screenshots_of_error_messages() throws IOException {
		
		Screenshots obj=new Screenshots();
		obj.Screenshot(driver);
		Assert.assertNotNull(obj);
		test = extent.createTest("screenshots_of_error_messsages","passed");		
		log.info("Taking Screenshot");
	}
    
    @Test(priority=7,dependsOnMethods = "on_roadprice")
    public void enter_name() throws IOException {
    	Read_xlsx obj3 = new Read_xlsx();
    	Scooter_details obj2 = new Scooter_details(driver);
    	Row row = obj3.input_file();
    	String name = obj3.input_name(row);
    	obj2.enter_name(name);
    	Assert.assertNotNull(obj2);
    	test = extent.createTest("enter_name", "passed");
    	log.info("Entering name "+name+" in the name field");
    }
    
    @Test(priority=8,dependsOnMethods = "on_roadprice")
    public void enter_mobile() throws IOException {
    	Read_xlsx obj3 = new Read_xlsx();
    	Scooter_details obj2 = new Scooter_details(driver);
    	Row row = obj3.input_file();
    	double mobile_no = obj3.input_mobile_no(row);
    	obj2.enter_mobile(mobile_no);
    	Assert.assertNotNull(obj2);
    	test = extent.createTest("enter_name", "passed");
    	log.info("Entering mobile number "+mobile_no+" in the mobile number field");
    }
    
    @Test(priority=9,dependsOnMethods = "on_roadprice")
    public void enter_city() throws IOException {
    	Read_xlsx obj3 = new Read_xlsx();
    	Scooter_details obj2 = new Scooter_details(driver);
    	Row row = obj3.input_file();
    	String city = obj3.input_city(row);
    	obj2.enter_city(city);
    	Assert.assertNotNull(obj2);
    	test = extent.createTest("enter_city", "passed");
    	log.info("Entering city "+city+" in the city field");
    }
    
    @Test(priority=10,dependsOnMethods = "on_roadprice")
    public void select_buytime() {
    	
    	test=extent.createTest("select_buytime", "passed");
    	Scooter_details obj2 = new Scooter_details(driver);
    	obj2.select_buytime();
    	log.info("Selecting the time to buy");
    }
    
    @Test(priority=11,dependsOnMethods = "on_roadprice")
    public void proceed() {
    	
    	test=extent.createTest("proceed", "passed");
    	Scooter_details obj2 = new Scooter_details(driver);
    	obj2.click_proceed();
    	log.info("Clicking on Proceed");
    }
    
    @Test(priority=12,dependsOnMethods="proceed_empty",groups="Outputs")
   	public void screenshots_of_Final_page() throws IOException {
   		
   		Screenshots obj=new Screenshots();
   		obj.Screenshot(driver);
   		Assert.assertNotNull(obj);
   		test = extent.createTest("screenshots_of_Final_page","passed");		
   		log.info("Taking Screenshot");
   	}
    
    @AfterTest
	public void exit() {
		driver.quit();
		log.info("Quiting the Browser");
		extent.flush();
	}
}
    
    



